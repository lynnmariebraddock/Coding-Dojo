from django.apps import AppConfig


class DojosurveyAppConfig(AppConfig):
    name = 'dojosurvey_app'
