from django.urls import path, include

urlpatterns = [
    path('', include('dojosurvey_app.urls')),
]
